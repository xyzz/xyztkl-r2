#pragma once

#define CH_CFG_ST_TIMEDELTA 0

#include_next <chconf.h>
